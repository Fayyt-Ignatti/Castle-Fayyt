﻿using Castle_Fayyt;
using HealValues;
using System;

namespace MagicAttack
{
  class Arcana
  {
    public static WeightedAttack<int> MagicPool = new WeightedAttack<int>();
    public static bool Lvl1_Instantiated = false;
    public static bool Lvl2_Instantiated = false;
    public static bool Lvl3_Instantiated = false;
    public static bool Lvl4_Instantiated = false;
    public static bool Lvl5_Instantiated = false;
    public static bool Lvl6_Instantiated = false;
    public static bool Lvl7_Instantiated = false;
    public static bool Lvl8_Instantiated = false;
    public static bool Lvl9_Instantiated = false;
    public static bool Lvl10_Instantiated = false;

    public static int Magic()
    {
      switch (Program.Hero_Lvl)
      {
        case 1:
          if (Lvl1_Instantiated == false)
          {
            WeightedAttack<int> Magic1 = new WeightedAttack<int>();
            Magic1.AddEntry(0, 10);
            Magic1.AddEntry(1, 10);
            Magic1.AddEntry(2, 18);
            Magic1.AddEntry(3, 32);
            Magic1.AddEntry(4, 24);
            Magic1.AddEntry(7, 6);

            MagicPool = Magic1;
            Lvl1_Instantiated = true;
          }

          int RandomPulledInternal = MagicPool.GetRandom();

          if (RandomPulledInternal == 0)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write(Heal.Lvl1_Full); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl1_Full;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 1)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Green; Console.Write(Heal.Lvl1_Half); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl1_Half;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 7)
          {
            Console.ForegroundColor = ConsoleColor.DarkRed; Console.Write("\t\tCritical Arcana!  {0} Damage!\n", RandomPulledInternal); Console.ResetColor();
            return RandomPulledInternal;
          }
          Console.WriteLine("\nThis attack is {0} damage.", RandomPulledInternal);
          return RandomPulledInternal;

        case 2:
          if (Lvl2_Instantiated == false)
          {
            WeightedAttack<int> Magic2 = new WeightedAttack<int>();
            Magic2.AddEntry(0, 10);
            Magic2.AddEntry(1, 10);
            Magic2.AddEntry(4, 20);
            Magic2.AddEntry(5, 31);
            Magic2.AddEntry(6, 23);
            Magic2.AddEntry(11, 6);

            MagicPool = Magic2;
            Lvl2_Instantiated = true;
            Console.WriteLine();
          }

          RandomPulledInternal = MagicPool.GetRandom();

          if (RandomPulledInternal == 0)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write(Heal.Lvl2_Full); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl2_Full;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 1)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Green; Console.Write(Heal.Lvl2_Half); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl2_Half;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 11)
          {
            Console.ForegroundColor = ConsoleColor.DarkRed; Console.Write("\t\tCritical Arcana!  {0} Damage!\n", RandomPulledInternal); Console.ResetColor();
            return RandomPulledInternal;
          }
          Console.WriteLine("\nThis attack is {0} damage.", RandomPulledInternal);
          return RandomPulledInternal;

        case 3:
          if (Lvl3_Instantiated == false)
          {
            WeightedAttack<int> Magic3 = new WeightedAttack<int>();
            Magic3.AddEntry(0, 10);
            Magic3.AddEntry(1, 10);
            Magic3.AddEntry(6, 22);
            Magic3.AddEntry(7, 30);
            Magic3.AddEntry(8, 21);
            Magic3.AddEntry(15, 7);

            MagicPool = Magic3;
            Lvl3_Instantiated = true;
            Console.WriteLine();
          }

          RandomPulledInternal = MagicPool.GetRandom();

          if (RandomPulledInternal == 0)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write(Heal.Lvl3_Full); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl3_Full;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 1)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Green; Console.Write(Heal.Lvl3_Half); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl3_Half;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 15)
          {
            Console.ForegroundColor = ConsoleColor.DarkRed; Console.Write("\t\tCritical Arcana!  {0} Damage!\n", RandomPulledInternal); Console.ResetColor();
            return RandomPulledInternal;
          }
          Console.WriteLine("\nThis attack is {0} damage.", RandomPulledInternal);
          return RandomPulledInternal;

        case 4:
          if (Lvl4_Instantiated == false)
          {
            WeightedAttack<int> Magic4 = new WeightedAttack<int>();
            Magic4.AddEntry(0, 10);
            Magic4.AddEntry(1, 10);
            Magic4.AddEntry(8, 21);
            Magic4.AddEntry(9, 30);
            Magic4.AddEntry(10, 22);
            Magic4.AddEntry(19, 7);

            MagicPool = Magic4;
            Lvl4_Instantiated = true;
            Console.WriteLine();
          }

          RandomPulledInternal = MagicPool.GetRandom();

          if (RandomPulledInternal == 0)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write(Heal.Lvl4_Full); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl4_Full;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 1)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Green; Console.Write(Heal.Lvl4_Half); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl4_Half;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 19)
          {
            Console.ForegroundColor = ConsoleColor.DarkRed; Console.Write("\t\tCritical Arcana!  {0} Damage!\n", RandomPulledInternal); Console.ResetColor();
            return RandomPulledInternal;
          }
          Console.WriteLine("\nThis attack is {0} damage.", RandomPulledInternal);
          return RandomPulledInternal;

        case 5:
          if (Lvl5_Instantiated == false)
          {
            WeightedAttack<int> Magic5 = new WeightedAttack<int>();
            Magic5.AddEntry(0, 10);
            Magic5.AddEntry(1, 10);
            Magic5.AddEntry(10, 20);
            Magic5.AddEntry(11, 31);
            Magic5.AddEntry(12, 21);
            Magic5.AddEntry(22, 8);

            MagicPool = Magic5;
            Lvl5_Instantiated = true;
            Console.WriteLine();
          }

          RandomPulledInternal = MagicPool.GetRandom();

          if (RandomPulledInternal == 0)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write(Heal.Lvl5_Full); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl5_Full;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 1)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Green; Console.Write(Heal.Lvl5_Half); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl5_Half;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 22)
          {
            Console.ForegroundColor = ConsoleColor.DarkRed; Console.Write("\t\tCritical Arcana!  {0} Damage!\n", RandomPulledInternal); Console.ResetColor();
            return RandomPulledInternal;
          }
          Console.WriteLine("\nThis attack is {0} damage.", RandomPulledInternal);
          return RandomPulledInternal;

        case 6:
          if (Lvl6_Instantiated == false)
          {
            WeightedAttack<int> Magic6 = new WeightedAttack<int>();
            Magic6.AddEntry(0, 10);
            Magic6.AddEntry(1, 10);
            Magic6.AddEntry(12, 21);
            Magic6.AddEntry(13, 32);
            Magic6.AddEntry(14, 18);
            Magic6.AddEntry(24, 9);

            MagicPool = Magic6;
            Lvl6_Instantiated = true;
            Console.WriteLine();
          }

          RandomPulledInternal = MagicPool.GetRandom();

          if (RandomPulledInternal == 0)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write(Heal.Lvl6_Full); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl6_Full;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 1)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Green; Console.Write(Heal.Lvl6_Half); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl6_Half;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 24)
          {
            Console.ForegroundColor = ConsoleColor.DarkRed; Console.Write("\t\tCritical Arcana!  {0} Damage!\n", RandomPulledInternal); Console.ResetColor();
            return RandomPulledInternal;
          }
          Console.WriteLine("\nThis attack is {0} damage.", RandomPulledInternal);
          return RandomPulledInternal;

        case 7:
          if (Lvl7_Instantiated == false)
          {
            WeightedAttack<int> Magic7 = new WeightedAttack<int>();
            Magic7.AddEntry(0, 10);
            Magic7.AddEntry(1, 10);
            Magic7.AddEntry(15, 16);
            Magic7.AddEntry(16, 20);
            Magic7.AddEntry(17, 22);
            Magic7.AddEntry(18, 12);
            Magic7.AddEntry(28, 10);

            MagicPool = Magic7;
            Lvl7_Instantiated = true;
            Console.WriteLine();
          }

          RandomPulledInternal = MagicPool.GetRandom();

          if (RandomPulledInternal == 0)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write(Heal.Lvl7_Full); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl7_Full;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 1)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Green; Console.Write(Heal.Lvl7_Half); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl7_Half;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 28)
          {
            Console.ForegroundColor = ConsoleColor.DarkRed; Console.Write("\t\tCritical Arcana!  {0} Damage!\n", RandomPulledInternal); Console.ResetColor();
            return RandomPulledInternal;
          }
          Console.WriteLine("\nThis attack is {0} damage.", RandomPulledInternal);
          return RandomPulledInternal;

        case 8:
          if (Lvl8_Instantiated == false)
          {
            WeightedAttack<int> Magic8 = new WeightedAttack<int>();
            Magic8.AddEntry(0, 10);
            Magic8.AddEntry(1, 10);
            Magic8.AddEntry(17, 16);
            Magic8.AddEntry(18, 18);
            Magic8.AddEntry(19, 22);
            Magic8.AddEntry(20, 13);
            Magic8.AddEntry(30, 11);

            MagicPool = Magic8;
            Lvl8_Instantiated = true;
            Console.WriteLine();
          }

          RandomPulledInternal = MagicPool.GetRandom();

          if (RandomPulledInternal == 0)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write(Heal.Lvl8_Full); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl8_Full;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 1)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Green; Console.Write(Heal.Lvl8_Half); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl8_Half;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 30)
          {
            Console.ForegroundColor = ConsoleColor.DarkRed; Console.Write("\t\tCritical Arcana!  {0} Damage!\n", RandomPulledInternal); Console.ResetColor();
            return RandomPulledInternal;
          }
          Console.WriteLine("\nThis attack is {0} damage.", RandomPulledInternal);
          return RandomPulledInternal;

        case 9:
          if (Lvl9_Instantiated == false)
          {
            WeightedAttack<int> Magic9 = new WeightedAttack<int>();
            Magic9.AddEntry(0, 10);
            Magic9.AddEntry(1, 9);
            Magic9.AddEntry(19, 6);
            Magic9.AddEntry(20, 8);
            Magic9.AddEntry(21, 14);
            Magic9.AddEntry(22, 22);
            Magic9.AddEntry(23, 10);
            Magic9.AddEntry(24, 9);
            Magic9.AddEntry(34, 12);

            MagicPool = Magic9;
            Lvl9_Instantiated = true;
            Console.WriteLine();
          }

          RandomPulledInternal = MagicPool.GetRandom();

          if (RandomPulledInternal == 0)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write(Heal.Lvl9_Full); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl9_Full;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 1)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Green; Console.Write(Heal.Lvl9_Half); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl9_Half;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 34)
          {
            Console.ForegroundColor = ConsoleColor.DarkRed; Console.Write("\t\tCritical Arcana!  {0} Damage!\n", RandomPulledInternal); Console.ResetColor();
            return RandomPulledInternal;
          }
          Console.WriteLine("\nThis attack is {0} damage.", RandomPulledInternal);
          return RandomPulledInternal;

        case 10:
          if (Lvl10_Instantiated == false)
          {
            WeightedAttack<int> Magic10 = new WeightedAttack<int>();
            Magic10.AddEntry(0, 10);
            Magic10.AddEntry(1, 8);
            Magic10.AddEntry(21, 6);
            Magic10.AddEntry(22, 6);
            Magic10.AddEntry(23, 8);
            Magic10.AddEntry(24, 12);
            Magic10.AddEntry(25, 18);
            Magic10.AddEntry(26, 10);
            Magic10.AddEntry(27, 8);
            Magic10.AddEntry(38, 14);

            MagicPool = Magic10;
            Lvl10_Instantiated = true;
            Console.WriteLine();
          }

          RandomPulledInternal = MagicPool.GetRandom();

          if (RandomPulledInternal == 0)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write(Heal.Lvl10_Full); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl10_Full;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 1)
          {
            Console.ForegroundColor = ConsoleColor.Blue; Console.Write("\t\tYou Healed "); Console.ForegroundColor = ConsoleColor.Green; Console.Write(Heal.Lvl10_Half); Console.ForegroundColor = ConsoleColor.Blue; Console.Write(" hit points.\n"); Console.ResetColor();

            Program.Hero_HP += Heal.Lvl10_Half;

            if (Program.Hero_HP > Program.Hero_HP_Max)
            {
              Program.Hero_HP = Program.Hero_HP_Max;
            }

            Console.Write("\nHero's current hit points are "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("{0}\n", Program.Hero_HP); Console.ResetColor();

            return 0;
          }

          else if (RandomPulledInternal == 38)
          {
            Console.ForegroundColor = ConsoleColor.DarkRed; Console.Write("\t\tCritical Arcana!  {0} Damage!\n", RandomPulledInternal); Console.ResetColor();
            return RandomPulledInternal;
          }
          Console.WriteLine("\nThis attack is {0} damage.", RandomPulledInternal);
          return RandomPulledInternal;
      }
      return 0;
    }
  }
}

