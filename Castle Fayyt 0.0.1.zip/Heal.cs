﻿namespace HealValues
{
  public class Heal
  {
    public static int Lvl1_Full
    {
      get { return 12; }
      set { Lvl1_Full = 12; }
    }

    public static int Lvl2_Full
    {
      get { return 18; }
      set { Lvl2_Full = 18; }
    }

    public static int Lvl3_Full
    {
      get { return 22; }
      set { Lvl3_Full = 22; }
    }

    public static int Lvl4_Full
    {
      get { return 28; }
      set { Lvl4_Full = 28; }
    }

    public static int Lvl5_Full
    {
      get { return 38; }
      set { Lvl5_Full = 38; }
    }

    public static int Lvl6_Full
    {
      get { return 48; }
      set { Lvl6_Full = 48; }
    }

    public static int Lvl7_Full
    {
      get { return 60; }
      set { Lvl7_Full = 60; }
    }

    public static int Lvl8_Full
    {
      get { return 72; }
      set { Lvl8_Full = 72; }
    }

    public static int Lvl9_Full
    {
      get { return 86; }
      set { Lvl9_Full = 86; }
    }

    public static int Lvl10_Full
    {
      get { return 100; }
      set { Lvl10_Full = 100; }
    }

    public static int Lvl1_Half
    {
      get { return 6; }
      set { Lvl1_Half = 6; }
    }

    public static int Lvl2_Half
    {
      get { return 9; }
      set { Lvl2_Half = 9; }
    }

    public static int Lvl3_Half
    {
      get { return 11; }
      set { Lvl3_Half = 11; }
    }

    public static int Lvl4_Half
    {
      get { return 14; }
      set { Lvl4_Half = 14; }
    }

    public static int Lvl5_Half
    {
      get { return 19; }
      set { Lvl5_Half = 19; }
    }

    public static int Lvl6_Half
    {
      get { return 24; }
      set { Lvl6_Half = 24; }
    }

    public static int Lvl7_Half
    {
      get { return 30; }
      set { Lvl7_Half = 30; }
    }

    public static int Lvl8_Half
    {
      get { return 36; }
      set { Lvl8_Half = 36; }
    }

    public static int Lvl9_Half
    {
      get { return 43; }
      set { Lvl9_Half = 43; }
    }

    public static int Lvl10_Half
    {
      get { return 50; }
      set { Lvl10_Half = 50; }
    }
  }
}
