﻿using MagicAttack;
using System;
using System.Collections.Generic;
using WeaponAttack;


namespace Castle_Fayyt
{
  class Program
  {

    public static int Fayyt_XP = 0;
    public static int Fayyt_HP = 0;

    public static int M6_HP = 100;
    public static int M9_HP = 150;
    public static int M12_HP = 150;
    public static int M14_HP = 100;
    public static int M56_HP = 200;
    public static int M47_HP = 200;
    public static int M39_HP = 400;
    public static int M30_HP = 300;
    public static int M20_HP = 300;

    public static int Hero_HP = 100;
    public static int Hero_HP_Max = 125;
    public static int Hero_XP = 0;
    public static int Hero_Lvl = 1;
    public static int count = 0;

    public static Dictionary<int, int> Hero_Lvl_Dict = new Dictionary<int, int>() { { 1, 0 }, { 2, 200 }, { 3, 400 }, { 4, 600 }, { 5, 800 }, { 6, 1100 }, { 7, 1500 }, { 8, 1900 }, { 9, 2400 }, { 10, 2900 } };
    public static Dictionary<int, int> Hero_HP_Max_Dict = new Dictionary<int, int>() { { 1, 125 }, { 2, 150 }, { 3, 175 }, { 4, 200 }, { 5, 250 }, { 6, 300 }, { 7, 350 }, { 8, 400 }, { 9, 450 }, { 10, 500 } };


    static void Main(string[] args)
    {
      for (int i = 0; i < 500; i++)
      {
        int Damage = 0;

        Random random = new Random();
        int choose = random.Next(1, 3);
        Console.WriteLine("Choose is {0}", choose);

        if (choose == 1)
        {
          Damage = Arcana.Magic();
        }

        else if (choose == 2)
        {
          Damage = Fight.Attack();
        }

        Console.WriteLine("{1}: This is the random damage done this turn: {0}", Damage, count);
        M6_HP = M6_HP - Damage;
        count++;
        if (Hero_Lvl == 10)
        {
          break;
        }
        if (M6_HP <= 0)
        {
          Hero_XP += 100;
          if (Hero_Lvl_Dict.TryGetValue(Hero_Lvl + 1, out int XP_Needed))
          {
            if (XP_Needed <= Hero_XP)
            {
              Hero_Lvl++;
              Hero_HP_Max_Dict.TryGetValue(Hero_Lvl, out int New_Max);
              Hero_HP_Max = New_Max;
              Console.ForegroundColor = ConsoleColor.Cyan; Console.Write("\t\tYou leveled up!  Current level is "); Console.ForegroundColor = ConsoleColor.Green; Console.Write("{0}", Hero_Lvl); Console.ResetColor();
              Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("\n\t\tYour new Max HP is "); Console.ForegroundColor = ConsoleColor.Green; Console.Write("{0}", Hero_HP_Max); Console.ResetColor();
              Console.WriteLine();
            }
          }
          Console.WriteLine("Monster is dead.  Congratualtions.  Yada-yada.");
          M6_HP = 100;
        }
        Console.WriteLine("This is the new M6 HP: {0}\n", M6_HP);
      }

    }
  }
}